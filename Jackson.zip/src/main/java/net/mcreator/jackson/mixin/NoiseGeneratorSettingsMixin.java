package net.mcreator.jackson.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.jackson.init.JacksonModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements JacksonModBiomes.JacksonModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> jackson_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.jackson_dimensionTypeReference != null) {
			retval = JacksonModBiomes.adaptSurfaceRule(retval, this.jackson_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setjacksonDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.jackson_dimensionTypeReference = dimensionType;
	}
}