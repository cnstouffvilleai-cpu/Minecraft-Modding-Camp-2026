package net.mcreator.jackson.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class LavaOreBlock extends Block {
	public LavaOreBlock(BlockBehaviour.Properties properties) {
		super(properties.strength(5f).requiresCorrectToolForDrops());
	}
}