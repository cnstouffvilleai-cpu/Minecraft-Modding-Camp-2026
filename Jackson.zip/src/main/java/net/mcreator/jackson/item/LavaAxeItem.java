package net.mcreator.jackson.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

import net.mcreator.jackson.procedures.LavaAxeLivingEntityIsHitWithToolProcedure;

public class LavaAxeItem extends AxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 2000, 100f, 0, 35, TagKey.create(Registries.ITEM, Identifier.parse("jackson:lava_axe_repair_items")));

	public LavaAxeItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 6999f, 96f, properties);
	}

	@Override
	public void hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		super.hurtEnemy(itemstack, entity, sourceentity);
		LavaAxeLivingEntityIsHitWithToolProcedure.execute(entity);
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}