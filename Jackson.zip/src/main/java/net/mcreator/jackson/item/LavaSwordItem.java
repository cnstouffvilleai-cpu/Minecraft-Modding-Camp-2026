package net.mcreator.jackson.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

import net.mcreator.jackson.procedures.LavaSwordLivingEntityIsHitWithToolProcedure;

public class LavaSwordItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 10000, 5f, 0, 35, TagKey.create(Registries.ITEM, Identifier.parse("jackson:lava_sword_repair_items")));

	public LavaSwordItem(Item.Properties properties) {
		super(properties.sword(TOOL_MATERIAL, 999f, 96f).fireResistant());
	}

	@Override
	public void hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		super.hurtEnemy(itemstack, entity, sourceentity);
		LavaSwordLivingEntityIsHitWithToolProcedure.execute(entity.level(), entity);
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}