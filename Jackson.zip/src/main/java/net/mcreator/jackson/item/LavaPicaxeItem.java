package net.mcreator.jackson.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class LavaPicaxeItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 1000, 5000f, 0, 35, TagKey.create(Registries.ITEM, Identifier.parse("jackson:lava_picaxe_repair_items")));

	public LavaPicaxeItem(Item.Properties properties) {
		super(properties.pickaxe(TOOL_MATERIAL, 4999f, 96f).fireResistant());
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}