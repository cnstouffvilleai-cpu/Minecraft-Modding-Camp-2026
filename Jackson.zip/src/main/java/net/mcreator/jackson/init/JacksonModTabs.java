/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jackson.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.jackson.JacksonMod;

@EventBusSubscriber
public class JacksonModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, JacksonMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> LAVATAB = REGISTRY.register("lavatab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.jackson.lavatab")).icon(() -> new ItemStack(JacksonModBlocks.LAVA_GRASS.get())).displayItems((parameters, tabData) -> {
				tabData.accept(JacksonModItems.LAVA_INGOT.get());
				tabData.accept(JacksonModItems.LAVA_SWORD.get());
				tabData.accept(JacksonModItems.LAVA_PICAXE.get());
				tabData.accept(JacksonModItems.LAVA_AXE.get());
				tabData.accept(JacksonModItems.LAVA_SHOVEL.get());
				tabData.accept(JacksonModItems.LAVA_HOE.get());
				tabData.accept(JacksonModItems.LAVA_ARMOR_HELMET.get());
				tabData.accept(JacksonModItems.LAVA_ARMOR_CHESTPLATE.get());
				tabData.accept(JacksonModItems.LAVA_ARMOR_LEGGINGS.get());
				tabData.accept(JacksonModItems.LAVA_ARMOR_BOOTS.get());
				tabData.accept(JacksonModItems.LAVA_SHURIKEN_ITEM.get());
				tabData.accept(JacksonModBlocks.LAVA_LOG.get().asItem());
				tabData.accept(JacksonModBlocks.LAVA_LEAVES.get().asItem());
				tabData.accept(JacksonModItems.LAVA_DIMENSION.get());
			}).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(JacksonModBlocks.LAVA_GRASS.get().asItem());
			tabData.accept(JacksonModBlocks.LAVA_ORE.get().asItem());
			tabData.accept(JacksonModBlocks.LAVA_LOG.get().asItem());
			tabData.accept(JacksonModBlocks.LAVA_LEAVES.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(JacksonModItems.LAVA_SWORD.get());
			tabData.accept(JacksonModItems.LAVA_PICAXE.get());
			tabData.accept(JacksonModItems.LAVA_AXE.get());
			tabData.accept(JacksonModItems.LAVA_SHOVEL.get());
			tabData.accept(JacksonModItems.LAVA_HOE.get());
			tabData.accept(JacksonModItems.LAVA_DIMENSION.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(JacksonModItems.LAVA_ARMOR_HELMET.get());
			tabData.accept(JacksonModItems.LAVA_ARMOR_CHESTPLATE.get());
			tabData.accept(JacksonModItems.LAVA_ARMOR_LEGGINGS.get());
			tabData.accept(JacksonModItems.LAVA_ARMOR_BOOTS.get());
			tabData.accept(JacksonModItems.LAVA_SHURIKEN_ITEM.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(JacksonModItems.ERNEST_THE_UNDEAD_KING_SPAWN_EGG.get());
		}
	}
}