/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jackson.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.jackson.block.LavaOreBlock;
import net.mcreator.jackson.block.LavaLogBlock;
import net.mcreator.jackson.block.LavaLeavesBlock;
import net.mcreator.jackson.block.LavaGrassBlock;
import net.mcreator.jackson.block.LavaDimensionPortalBlock;
import net.mcreator.jackson.JacksonMod;

import java.util.function.Function;

public class JacksonModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(JacksonMod.MODID);
	public static final DeferredBlock<Block> LAVA_GRASS;
	public static final DeferredBlock<Block> LAVA_ORE;
	public static final DeferredBlock<Block> LAVA_LOG;
	public static final DeferredBlock<Block> LAVA_LEAVES;
	public static final DeferredBlock<Block> LAVA_DIMENSION_PORTAL;
	static {
		LAVA_GRASS = register("lava_grass", LavaGrassBlock::new);
		LAVA_ORE = register("lava_ore", LavaOreBlock::new);
		LAVA_LOG = register("lava_log", LavaLogBlock::new);
		LAVA_LEAVES = register("lava_leaves", LavaLeavesBlock::new);
		LAVA_DIMENSION_PORTAL = register("lava_dimension_portal", LavaDimensionPortalBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}