/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jackson.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

import net.mcreator.jackson.entity.LavaShurikenEntity;
import net.mcreator.jackson.entity.ErnestTheUndeadKingEntity;
import net.mcreator.jackson.JacksonMod;

@EventBusSubscriber
public class JacksonModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, JacksonMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<LavaShurikenEntity>> LAVA_SHURIKEN = register("lava_shuriken",
			EntityType.Builder.<LavaShurikenEntity>of(LavaShurikenEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final DeferredHolder<EntityType<?>, EntityType<ErnestTheUndeadKingEntity>> ERNEST_THE_UNDEAD_KING = register("ernest_the_undead_king",
			EntityType.Builder.<ErnestTheUndeadKingEntity>of(ErnestTheUndeadKingEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.ridingOffset(-0.6f).sized(0.6f, 1.8f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(ResourceKey.create(Registries.ENTITY_TYPE, Identifier.fromNamespaceAndPath(JacksonMod.MODID, registryname))));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		ErnestTheUndeadKingEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(ERNEST_THE_UNDEAD_KING.get(), ErnestTheUndeadKingEntity.createAttributes().build());
	}
}