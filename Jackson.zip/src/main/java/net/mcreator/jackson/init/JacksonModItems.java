/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jackson.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.jackson.item.*;
import net.mcreator.jackson.JacksonMod;

import java.util.function.Function;

public class JacksonModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(JacksonMod.MODID);
	public static final DeferredItem<Item> LAVA_GRASS;
	public static final DeferredItem<Item> LAVA_ORE;
	public static final DeferredItem<Item> LAVA_INGOT;
	public static final DeferredItem<Item> LAVA_SWORD;
	public static final DeferredItem<Item> LAVA_PICAXE;
	public static final DeferredItem<Item> LAVA_AXE;
	public static final DeferredItem<Item> LAVA_SHOVEL;
	public static final DeferredItem<Item> LAVA_HOE;
	public static final DeferredItem<Item> LAVA_ARMOR_HELMET;
	public static final DeferredItem<Item> LAVA_ARMOR_CHESTPLATE;
	public static final DeferredItem<Item> LAVA_ARMOR_LEGGINGS;
	public static final DeferredItem<Item> LAVA_ARMOR_BOOTS;
	public static final DeferredItem<Item> LAVA_SHURIKEN_ITEM;
	public static final DeferredItem<Item> ERNEST_THE_UNDEAD_KING_SPAWN_EGG;
	public static final DeferredItem<Item> LAVA_LOG;
	public static final DeferredItem<Item> LAVA_LEAVES;
	public static final DeferredItem<Item> LAVA_DIMENSION;
	static {
		LAVA_GRASS = block(JacksonModBlocks.LAVA_GRASS);
		LAVA_ORE = block(JacksonModBlocks.LAVA_ORE);
		LAVA_INGOT = register("lava_ingot", LavaIngotItem::new);
		LAVA_SWORD = register("lava_sword", LavaSwordItem::new);
		LAVA_PICAXE = register("lava_picaxe", LavaPicaxeItem::new);
		LAVA_AXE = register("lava_axe", LavaAxeItem::new);
		LAVA_SHOVEL = register("lava_shovel", LavaShovelItem::new);
		LAVA_HOE = register("lava_hoe", LavaHoeItem::new);
		LAVA_ARMOR_HELMET = register("lava_armor_helmet", LavaArmorItem.Helmet::new);
		LAVA_ARMOR_CHESTPLATE = register("lava_armor_chestplate", LavaArmorItem.Chestplate::new);
		LAVA_ARMOR_LEGGINGS = register("lava_armor_leggings", LavaArmorItem.Leggings::new);
		LAVA_ARMOR_BOOTS = register("lava_armor_boots", LavaArmorItem.Boots::new);
		LAVA_SHURIKEN_ITEM = register("lava_shuriken_item", LavaShurikenItemItem::new);
		ERNEST_THE_UNDEAD_KING_SPAWN_EGG = register("ernest_the_undead_king_spawn_egg", properties -> new SpawnEggItem(properties.spawnEgg(JacksonModEntities.ERNEST_THE_UNDEAD_KING.get())));
		LAVA_LOG = block(JacksonModBlocks.LAVA_LOG);
		LAVA_LEAVES = block(JacksonModBlocks.LAVA_LEAVES);
		LAVA_DIMENSION = register("lava_dimension", LavaDimensionItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, Item.Properties::new);
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), () -> properties);
	}
}