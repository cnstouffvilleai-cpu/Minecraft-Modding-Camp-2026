/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jackson.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.jackson.client.renderer.ErnestTheUndeadKingRenderer;

@EventBusSubscriber(Dist.CLIENT)
public class JacksonModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(JacksonModEntities.LAVA_SHURIKEN.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(JacksonModEntities.ERNEST_THE_UNDEAD_KING.get(), ErnestTheUndeadKingRenderer::new);
	}
}