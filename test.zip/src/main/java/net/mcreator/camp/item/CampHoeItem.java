package net.mcreator.camp.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.HoeItem;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class CampHoeItem extends HoeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 832, 8f, 0, 16, TagKey.create(Registries.ITEM, ResourceLocation.parse("camp:camp_hoe_repair_items")));

	public CampHoeItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 3f, -2.8f, properties);
	}
}