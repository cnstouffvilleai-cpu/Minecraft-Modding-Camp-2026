/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.camp.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.camp.item.CampSwordItem;
import net.mcreator.camp.item.CampIngotItem;
import net.mcreator.camp.item.CampHoeItem;
import net.mcreator.camp.CampMod;

import java.util.function.Function;

public class CampModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(CampMod.MODID);
	public static final DeferredItem<Item> CAMP_GRASS;
	public static final DeferredItem<Item> CAMP_ORE;
	public static final DeferredItem<Item> CAMP_INGOT;
	public static final DeferredItem<Item> CAMP_SWORD;
	public static final DeferredItem<Item> CAMP_HOE;
	static {
		CAMP_GRASS = block(CampModBlocks.CAMP_GRASS);
		CAMP_ORE = block(CampModBlocks.CAMP_ORE);
		CAMP_INGOT = register("camp_ingot", CampIngotItem::new);
		CAMP_SWORD = register("camp_sword", CampSwordItem::new);
		CAMP_HOE = register("camp_hoe", CampHoeItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}