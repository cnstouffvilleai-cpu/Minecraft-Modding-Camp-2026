/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.damianl.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.damianl.DamianlMod;

@EventBusSubscriber
public class DamianlModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, DamianlMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> INVINTORY = REGISTRY.register("invintory",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.damianl.invintory")).icon(() -> new ItemStack(DamianlModBlocks.FIREGRASS.get())).displayItems((parameters, tabData) -> {
				tabData.accept(DamianlModBlocks.WATTERORE.get().asItem());
				tabData.accept(DamianlModItems.FIRE_SWORD.get());
				tabData.accept(DamianlModItems.FIRE_AXE.get());
				tabData.accept(DamianlModItems.FIREWATTERHOE.get());
				tabData.accept(DamianlModItems.FIREARMOUR_HELMET.get());
				tabData.accept(DamianlModItems.FIREARMOUR_CHESTPLATE.get());
				tabData.accept(DamianlModItems.FIREARMOUR_LEGGINGS.get());
				tabData.accept(DamianlModItems.FIREARMOUR_BOOTS.get());
				tabData.accept(DamianlModItems.FIRE_NINJA_STAR_ITEM.get());
				tabData.accept(DamianlModBlocks.FIRE_LOG.get().asItem());
			}).build());
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> WATTER = REGISTRY.register("watter",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.damianl.watter")).icon(() -> new ItemStack(DamianlModBlocks.WATTERORE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(DamianlModItems.WATTERINGIT.get());
				tabData.accept(DamianlModItems.FIRE_PICKAXE.get());
				tabData.accept(DamianlModItems.WATER_SHOVEL.get());
			}).withTabsBefore(INVINTORY.getId()).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(DamianlModBlocks.FIREGRASS.get().asItem());
			tabData.accept(DamianlModBlocks.WATTERORE.get().asItem());
			tabData.accept(DamianlModBlocks.FIRE_LOG.get().asItem());
			tabData.accept(DamianlModBlocks.FIRE_LEAVES.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(DamianlModItems.FIRE_SWORD.get());
			tabData.accept(DamianlModItems.FIRE_PICKAXE.get());
			tabData.accept(DamianlModItems.WATER_SHOVEL.get());
			tabData.accept(DamianlModItems.FIRE_AXE.get());
			tabData.accept(DamianlModItems.FIREWATTERHOE.get());
			tabData.accept(DamianlModItems.FIRE_DIMENSION.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(DamianlModItems.FIREARMOUR_HELMET.get());
			tabData.accept(DamianlModItems.FIREARMOUR_CHESTPLATE.get());
			tabData.accept(DamianlModItems.FIREARMOUR_LEGGINGS.get());
			tabData.accept(DamianlModItems.FIREARMOUR_BOOTS.get());
			tabData.accept(DamianlModItems.FIRE_NINJA_STAR_ITEM.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(DamianlModItems.ROSALEANA_SPAWN_EGG.get());
		}
	}
}