/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.damianl.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.damianl.client.renderer.RosaleanaRenderer;

@EventBusSubscriber(Dist.CLIENT)
public class DamianlModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(DamianlModEntities.FIRE_NINJA_STAR.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(DamianlModEntities.ROSALEANA.get(), RosaleanaRenderer::new);
	}
}