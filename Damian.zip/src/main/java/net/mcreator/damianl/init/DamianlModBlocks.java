/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.damianl.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.damianl.block.WatteroreBlock;
import net.mcreator.damianl.block.FiregrassBlock;
import net.mcreator.damianl.block.FireLogBlock;
import net.mcreator.damianl.block.FireLeavesBlock;
import net.mcreator.damianl.block.FireDimensionPortalBlock;
import net.mcreator.damianl.DamianlMod;

import java.util.function.Function;

public class DamianlModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(DamianlMod.MODID);
	public static final DeferredBlock<Block> FIREGRASS;
	public static final DeferredBlock<Block> WATTERORE;
	public static final DeferredBlock<Block> FIRE_LOG;
	public static final DeferredBlock<Block> FIRE_LEAVES;
	public static final DeferredBlock<Block> FIRE_DIMENSION_PORTAL;
	static {
		FIREGRASS = register("firegrass", FiregrassBlock::new);
		WATTERORE = register("watterore", WatteroreBlock::new);
		FIRE_LOG = register("fire_log", FireLogBlock::new);
		FIRE_LEAVES = register("fire_leaves", FireLeavesBlock::new);
		FIRE_DIMENSION_PORTAL = register("fire_dimension_portal", FireDimensionPortalBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}