/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.damianl.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.damianl.item.*;
import net.mcreator.damianl.DamianlMod;

import java.util.function.Function;

public class DamianlModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(DamianlMod.MODID);
	public static final DeferredItem<Item> FIREGRASS;
	public static final DeferredItem<Item> WATTERORE;
	public static final DeferredItem<Item> WATTERINGIT;
	public static final DeferredItem<Item> FIRE_SWORD;
	public static final DeferredItem<Item> FIRE_PICKAXE;
	public static final DeferredItem<Item> WATER_SHOVEL;
	public static final DeferredItem<Item> FIRE_AXE;
	public static final DeferredItem<Item> FIREWATTERHOE;
	public static final DeferredItem<Item> FIREARMOUR_HELMET;
	public static final DeferredItem<Item> FIREARMOUR_CHESTPLATE;
	public static final DeferredItem<Item> FIREARMOUR_LEGGINGS;
	public static final DeferredItem<Item> FIREARMOUR_BOOTS;
	public static final DeferredItem<Item> FIRE_NINJA_STAR_ITEM;
	public static final DeferredItem<Item> ROSALEANA_SPAWN_EGG;
	public static final DeferredItem<Item> FIRE_LOG;
	public static final DeferredItem<Item> FIRE_LEAVES;
	public static final DeferredItem<Item> FIRE_DIMENSION;
	static {
		FIREGRASS = block(DamianlModBlocks.FIREGRASS);
		WATTERORE = block(DamianlModBlocks.WATTERORE);
		WATTERINGIT = register("watteringit", WatteringitItem::new);
		FIRE_SWORD = register("fire_sword", FireSwordItem::new);
		FIRE_PICKAXE = register("fire_pickaxe", FirePickaxeItem::new);
		WATER_SHOVEL = register("water_shovel", WaterShovelItem::new);
		FIRE_AXE = register("fire_axe", FireAxeItem::new);
		FIREWATTERHOE = register("firewatterhoe", FirewatterhoeItem::new);
		FIREARMOUR_HELMET = register("firearmour_helmet", FirearmourItem.Helmet::new);
		FIREARMOUR_CHESTPLATE = register("firearmour_chestplate", FirearmourItem.Chestplate::new);
		FIREARMOUR_LEGGINGS = register("firearmour_leggings", FirearmourItem.Leggings::new);
		FIREARMOUR_BOOTS = register("firearmour_boots", FirearmourItem.Boots::new);
		FIRE_NINJA_STAR_ITEM = register("fire_ninja_star_item", FireNinjaStarItemItem::new);
		ROSALEANA_SPAWN_EGG = register("rosaleana_spawn_egg", properties -> new SpawnEggItem(properties.spawnEgg(DamianlModEntities.ROSALEANA.get())));
		FIRE_LOG = block(DamianlModBlocks.FIRE_LOG);
		FIRE_LEAVES = block(DamianlModBlocks.FIRE_LEAVES);
		FIRE_DIMENSION = register("fire_dimension", FireDimensionItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, Item.Properties::new);
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), () -> properties);
	}
}