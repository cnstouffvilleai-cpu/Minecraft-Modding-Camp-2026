package net.mcreator.damianl.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class FireSwordItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 1000, 4f, 0, 708, TagKey.create(Registries.ITEM, Identifier.parse("damianl:fire_sword_repair_items")));

	public FireSwordItem(Item.Properties properties) {
		super(properties.sword(TOOL_MATERIAL, 31.9f, 36f));
	}
}