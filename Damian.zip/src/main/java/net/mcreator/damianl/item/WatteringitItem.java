package net.mcreator.damianl.item;

import net.minecraft.world.item.Item;

public class WatteringitItem extends Item {
	public WatteringitItem(Item.Properties properties) {
		super(properties);
	}
}