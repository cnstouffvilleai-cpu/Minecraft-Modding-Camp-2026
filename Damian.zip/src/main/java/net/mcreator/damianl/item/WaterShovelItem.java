package net.mcreator.damianl.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class WaterShovelItem extends ShovelItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 103, 5f, 0, 10, TagKey.create(Registries.ITEM, Identifier.parse("damianl:water_shovel_repair_items")));

	public WaterShovelItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 4f, -2f, properties);
	}
}