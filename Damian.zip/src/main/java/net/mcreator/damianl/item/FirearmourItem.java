package net.mcreator.damianl.item;

import net.minecraft.world.item.equipment.EquipmentAssets;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.registries.BuiltInRegistries;

import java.util.Map;

public abstract class FirearmourItem extends Item {
	public static ArmorMaterial ARMOR_MATERIAL = new ArmorMaterial(67, Map.of(ArmorType.BOOTS, 37, ArmorType.LEGGINGS, 15, ArmorType.CHESTPLATE, 16, ArmorType.HELMET, 8, ArmorType.BODY, 16), 36,
			BuiltInRegistries.SOUND_EVENT.wrapAsHolder(SoundEvents.EMPTY), 10f, 5f, TagKey.create(Registries.ITEM, Identifier.parse("damianl:firearmour_repair_items")),
			ResourceKey.create(EquipmentAssets.ROOT_ID, Identifier.parse("damianl:firearmour")));

	private FirearmourItem(Item.Properties properties) {
		super(properties);
	}

	public static class Helmet extends FirearmourItem {
		public Helmet(Item.Properties properties) {
			super(properties.humanoidArmor(ARMOR_MATERIAL, ArmorType.HELMET));
		}
	}

	public static class Chestplate extends FirearmourItem {
		public Chestplate(Item.Properties properties) {
			super(properties.humanoidArmor(ARMOR_MATERIAL, ArmorType.CHESTPLATE));
		}
	}

	public static class Leggings extends FirearmourItem {
		public Leggings(Item.Properties properties) {
			super(properties.humanoidArmor(ARMOR_MATERIAL, ArmorType.LEGGINGS));
		}
	}

	public static class Boots extends FirearmourItem {
		public Boots(Item.Properties properties) {
			super(properties.humanoidArmor(ARMOR_MATERIAL, ArmorType.BOOTS));
		}
	}
}