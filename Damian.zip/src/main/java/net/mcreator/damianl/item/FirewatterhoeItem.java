package net.mcreator.damianl.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.HoeItem;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class FirewatterhoeItem extends HoeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 110, 0f, 0, 10, TagKey.create(Registries.ITEM, Identifier.parse("damianl:firewatterhoe_repair_items")));

	public FirewatterhoeItem(Item.Properties properties) {
		super(TOOL_MATERIAL, -1f, -4f, properties);
	}
}