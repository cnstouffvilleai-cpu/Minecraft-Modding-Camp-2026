package net.mcreator.damianl.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class FireAxeItem extends AxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 100, 5f, 0, 2, TagKey.create(Registries.ITEM, Identifier.parse("damianl:fire_axe_repair_items")));

	public FireAxeItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 5f, -1f, properties);
	}
}