package net.mcreator.damianl.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

public class FirePickaxeLivingEntityIsHitWithToolProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		world.setBlock(BlockPos.containing(entity.getX(), 5, entity.getZ()), Blocks.ANVIL.defaultBlockState(), 3);
	}
}