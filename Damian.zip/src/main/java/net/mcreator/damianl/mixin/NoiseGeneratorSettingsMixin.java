package net.mcreator.damianl.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.damianl.init.DamianlModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements DamianlModBiomes.DamianlModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> damianl_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.damianl_dimensionTypeReference != null) {
			retval = DamianlModBiomes.adaptSurfaceRule(retval, this.damianl_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setdamianlDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.damianl_dimensionTypeReference = dimensionType;
	}
}