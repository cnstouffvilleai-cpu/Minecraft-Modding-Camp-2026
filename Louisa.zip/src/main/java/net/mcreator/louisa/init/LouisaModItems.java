/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.louisa.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.louisa.item.*;
import net.mcreator.louisa.LouisaMod;

import java.util.function.Function;

public class LouisaModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(LouisaMod.MODID);
	public static final DeferredItem<Item> DIFFERENT_GRASS;
	public static final DeferredItem<Item> ORE;
	public static final DeferredItem<Item> LAVA_INGOT;
	public static final DeferredItem<Item> LAVA_SWORD;
	public static final DeferredItem<Item> PICKAXE;
	public static final DeferredItem<Item> LAVA_AXE;
	public static final DeferredItem<Item> LAV_SHOVEL;
	public static final DeferredItem<Item> LAVA_HOE;
	public static final DeferredItem<Item> LAVA_ARMOR_HELMET;
	public static final DeferredItem<Item> LAVA_ARMOR_CHESTPLATE;
	public static final DeferredItem<Item> LAVA_ARMOR_LEGGINGS;
	public static final DeferredItem<Item> LAVA_ARMOR_BOOTS;
	public static final DeferredItem<Item> LAVA_STAR;
	public static final DeferredItem<Item> VADER_SPAWN_EGG;
	public static final DeferredItem<Item> LAVA_LOG;
	public static final DeferredItem<Item> L_AVA_LEAVES;
	public static final DeferredItem<Item> LAVA_DIMENSION;
	static {
		DIFFERENT_GRASS = block(LouisaModBlocks.DIFFERENT_GRASS);
		ORE = block(LouisaModBlocks.ORE);
		LAVA_INGOT = register("lava_ingot", LavaIngotItem::new);
		LAVA_SWORD = register("lava_sword", LavaSwordItem::new);
		PICKAXE = register("pickaxe", PICKAXEItem::new);
		LAVA_AXE = register("lava_axe", LavaAxeItem::new);
		LAV_SHOVEL = register("lav_shovel", LavShovelItem::new);
		LAVA_HOE = register("lava_hoe", LavaHoeItem::new);
		LAVA_ARMOR_HELMET = register("lava_armor_helmet", LavaArmorItem.Helmet::new);
		LAVA_ARMOR_CHESTPLATE = register("lava_armor_chestplate", LavaArmorItem.Chestplate::new);
		LAVA_ARMOR_LEGGINGS = register("lava_armor_leggings", LavaArmorItem.Leggings::new);
		LAVA_ARMOR_BOOTS = register("lava_armor_boots", LavaArmorItem.Boots::new);
		LAVA_STAR = register("lava_star", LavaStarItem::new);
		VADER_SPAWN_EGG = register("vader_spawn_egg", properties -> new SpawnEggItem(properties.spawnEgg(LouisaModEntities.VADER.get())));
		LAVA_LOG = block(LouisaModBlocks.LAVA_LOG);
		L_AVA_LEAVES = block(LouisaModBlocks.L_AVA_LEAVES);
		LAVA_DIMENSION = register("lava_dimension", LavaDimensionItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, Item.Properties::new);
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), () -> properties);
	}
}