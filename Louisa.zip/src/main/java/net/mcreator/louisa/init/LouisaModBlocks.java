/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.louisa.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.louisa.block.OREBlock;
import net.mcreator.louisa.block.LavaLogBlock;
import net.mcreator.louisa.block.LavaDimensionPortalBlock;
import net.mcreator.louisa.block.LAvaLeavesBlock;
import net.mcreator.louisa.block.DifferentGrassBlock;
import net.mcreator.louisa.LouisaMod;

import java.util.function.Function;

public class LouisaModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(LouisaMod.MODID);
	public static final DeferredBlock<Block> DIFFERENT_GRASS;
	public static final DeferredBlock<Block> ORE;
	public static final DeferredBlock<Block> LAVA_LOG;
	public static final DeferredBlock<Block> L_AVA_LEAVES;
	public static final DeferredBlock<Block> LAVA_DIMENSION_PORTAL;
	static {
		DIFFERENT_GRASS = register("different_grass", DifferentGrassBlock::new);
		ORE = register("ore", OREBlock::new);
		LAVA_LOG = register("lava_log", LavaLogBlock::new);
		L_AVA_LEAVES = register("l_ava_leaves", LAvaLeavesBlock::new);
		LAVA_DIMENSION_PORTAL = register("lava_dimension_portal", LavaDimensionPortalBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}