/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.louisa.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.louisa.LouisaMod;

@EventBusSubscriber
public class LouisaModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LouisaMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> LOUISA_TAB = REGISTRY.register("louisa_tab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.louisa.louisa_tab")).icon(() -> new ItemStack(LouisaModBlocks.ORE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(LouisaModBlocks.DIFFERENT_GRASS.get().asItem());
				tabData.accept(LouisaModBlocks.ORE.get().asItem());
				tabData.accept(LouisaModItems.LAVA_INGOT.get());
				tabData.accept(LouisaModItems.LAVA_SWORD.get());
				tabData.accept(LouisaModItems.PICKAXE.get());
				tabData.accept(LouisaModItems.LAVA_AXE.get());
				tabData.accept(LouisaModItems.LAV_SHOVEL.get());
				tabData.accept(LouisaModItems.LAVA_HOE.get());
				tabData.accept(LouisaModItems.LAVA_ARMOR_HELMET.get());
				tabData.accept(LouisaModItems.LAVA_ARMOR_CHESTPLATE.get());
				tabData.accept(LouisaModItems.LAVA_ARMOR_LEGGINGS.get());
				tabData.accept(LouisaModItems.LAVA_ARMOR_BOOTS.get());
				tabData.accept(LouisaModItems.LAVA_STAR.get());
				tabData.accept(LouisaModBlocks.LAVA_LOG.get().asItem());
				tabData.accept(LouisaModBlocks.L_AVA_LEAVES.get().asItem());
				tabData.accept(LouisaModItems.LAVA_DIMENSION.get());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(LouisaModBlocks.DIFFERENT_GRASS.get().asItem());
			tabData.accept(LouisaModBlocks.ORE.get().asItem());
			tabData.accept(LouisaModBlocks.LAVA_LOG.get().asItem());
			tabData.accept(LouisaModBlocks.L_AVA_LEAVES.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(LouisaModItems.LAVA_SWORD.get());
			tabData.accept(LouisaModItems.LAVA_ARMOR_HELMET.get());
			tabData.accept(LouisaModItems.LAVA_ARMOR_CHESTPLATE.get());
			tabData.accept(LouisaModItems.LAVA_ARMOR_LEGGINGS.get());
			tabData.accept(LouisaModItems.LAVA_ARMOR_BOOTS.get());
			tabData.accept(LouisaModItems.LAVA_STAR.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(LouisaModItems.LAV_SHOVEL.get());
			tabData.accept(LouisaModItems.LAVA_HOE.get());
			tabData.accept(LouisaModItems.LAVA_DIMENSION.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(LouisaModItems.VADER_SPAWN_EGG.get());
		}
	}
}