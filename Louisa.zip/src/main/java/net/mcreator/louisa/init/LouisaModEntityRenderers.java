/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.louisa.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.louisa.client.renderer.VaderRenderer;

@EventBusSubscriber(Dist.CLIENT)
public class LouisaModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(LouisaModEntities.LAVA_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(LouisaModEntities.VADER.get(), VaderRenderer::new);
	}
}