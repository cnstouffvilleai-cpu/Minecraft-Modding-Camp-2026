package net.mcreator.louisa.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.louisa.init.LouisaModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements LouisaModBiomes.LouisaModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> louisa_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.louisa_dimensionTypeReference != null) {
			retval = LouisaModBiomes.adaptSurfaceRule(retval, this.louisa_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setlouisaDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.louisa_dimensionTypeReference = dimensionType;
	}
}