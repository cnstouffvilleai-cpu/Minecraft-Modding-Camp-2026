package net.mcreator.louisa.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class PICKAXEItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 100, 120f, 0, 2, TagKey.create(Registries.ITEM, Identifier.parse("louisa:pickaxe_repair_items")));

	public PICKAXEItem(Item.Properties properties) {
		super(properties.pickaxe(TOOL_MATERIAL, 119f, -3f).rarity(Rarity.EPIC).fireResistant());
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}