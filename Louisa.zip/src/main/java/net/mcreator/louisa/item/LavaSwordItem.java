package net.mcreator.louisa.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class LavaSwordItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 120, 5f, 0, 120, TagKey.create(Registries.ITEM, Identifier.parse("louisa:lava_sword_repair_items")));

	public LavaSwordItem(Item.Properties properties) {
		super(properties.sword(TOOL_MATERIAL, 119f, -1.5f).fireResistant());
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}