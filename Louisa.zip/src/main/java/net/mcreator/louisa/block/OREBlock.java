package net.mcreator.louisa.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class OREBlock extends Block {
	public OREBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.GLASS).strength(4f, 9.5f).requiresCorrectToolForDrops());
	}
}