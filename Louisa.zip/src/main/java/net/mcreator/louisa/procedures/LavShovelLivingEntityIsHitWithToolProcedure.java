package net.mcreator.louisa.procedures;

import net.minecraft.world.entity.Entity;

public class LavShovelLivingEntityIsHitWithToolProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.igniteForSeconds(20);
	}
}