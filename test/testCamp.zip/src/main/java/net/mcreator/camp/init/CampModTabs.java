/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.camp.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.camp.CampMod;

@EventBusSubscriber
public class CampModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CampMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> CAMP_TAB = REGISTRY.register("camp_tab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.camp.camp_tab")).icon(() -> new ItemStack(CampModBlocks.CAMP_ORE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(CampModBlocks.CAMP_GRASS.get().asItem());
				tabData.accept(CampModBlocks.CAMP_ORE.get().asItem());
				tabData.accept(CampModItems.CAMP_INGOT.get());
				tabData.accept(CampModItems.CAMP_SWORD.get());
				tabData.accept(CampModItems.CAMP_HOE.get());
				tabData.accept(CampModItems.CAMP_ARMOUR_HELMET.get());
				tabData.accept(CampModItems.CAMP_ARMOUR_CHESTPLATE.get());
				tabData.accept(CampModItems.CAMP_ARMOUR_LEGGINGS.get());
				tabData.accept(CampModItems.CAMP_ARMOUR_BOOTS.get());
				tabData.accept(CampModItems.CAMP_PICKAXE.get());
				tabData.accept(CampModItems.CAMP_SHOVEL.get());
				tabData.accept(CampModItems.CAMP_AXE.get());
				tabData.accept(CampModItems.CAMP_SHEARS.get());
				tabData.accept(CampModItems.SHURIKEN_ITEM.get());
			}).build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(CampModBlocks.CAMP_GRASS.get().asItem());
			tabData.accept(CampModBlocks.CAMP_ORE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(CampModItems.CAMP_SWORD.get());
			tabData.accept(CampModItems.CAMP_ARMOUR_HELMET.get());
			tabData.accept(CampModItems.CAMP_ARMOUR_CHESTPLATE.get());
			tabData.accept(CampModItems.CAMP_ARMOUR_LEGGINGS.get());
			tabData.accept(CampModItems.CAMP_ARMOUR_BOOTS.get());
			tabData.accept(CampModItems.SHURIKEN_ITEM.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(CampModItems.CAMP_HOE.get());
			tabData.accept(CampModItems.CAMP_PICKAXE.get());
			tabData.accept(CampModItems.CAMP_SHOVEL.get());
			tabData.accept(CampModItems.CAMP_AXE.get());
			tabData.accept(CampModItems.CAMP_SHEARS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(CampModItems.MALICIOUS_J_VAMPIRE_SPAWN_EGG.get());
		}
	}
}