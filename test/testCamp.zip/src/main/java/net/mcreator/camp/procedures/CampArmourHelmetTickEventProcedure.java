package net.mcreator.camp.procedures;

public class CampArmourHelmetTickEventProcedure {
	public static void execute() {
	}
}