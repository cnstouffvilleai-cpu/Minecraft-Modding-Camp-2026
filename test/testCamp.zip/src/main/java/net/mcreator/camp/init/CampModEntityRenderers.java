/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.camp.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.camp.client.renderer.MaliciousJVampireRenderer;

@EventBusSubscriber(Dist.CLIENT)
public class CampModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(CampModEntities.SHURIKEN.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(CampModEntities.MALICIOUS_J_VAMPIRE.get(), MaliciousJVampireRenderer::new);
	}
}