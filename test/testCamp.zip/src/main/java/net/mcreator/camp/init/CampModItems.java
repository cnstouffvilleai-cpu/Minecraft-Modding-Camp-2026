/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.camp.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.camp.item.*;
import net.mcreator.camp.CampMod;

import java.util.function.Function;

public class CampModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(CampMod.MODID);
	public static final DeferredItem<Item> CAMP_GRASS;
	public static final DeferredItem<Item> CAMP_ORE;
	public static final DeferredItem<Item> CAMP_INGOT;
	public static final DeferredItem<Item> CAMP_SWORD;
	public static final DeferredItem<Item> CAMP_HOE;
	public static final DeferredItem<Item> CAMP_ARMOUR_HELMET;
	public static final DeferredItem<Item> CAMP_ARMOUR_CHESTPLATE;
	public static final DeferredItem<Item> CAMP_ARMOUR_LEGGINGS;
	public static final DeferredItem<Item> CAMP_ARMOUR_BOOTS;
	public static final DeferredItem<Item> CAMP_PICKAXE;
	public static final DeferredItem<Item> CAMP_SHOVEL;
	public static final DeferredItem<Item> CAMP_AXE;
	public static final DeferredItem<Item> CAMP_SHEARS;
	public static final DeferredItem<Item> SHURIKEN_ITEM;
	public static final DeferredItem<Item> MALICIOUS_J_VAMPIRE_SPAWN_EGG;
	static {
		CAMP_GRASS = block(CampModBlocks.CAMP_GRASS);
		CAMP_ORE = block(CampModBlocks.CAMP_ORE);
		CAMP_INGOT = register("camp_ingot", CampIngotItem::new);
		CAMP_SWORD = register("camp_sword", CampSwordItem::new);
		CAMP_HOE = register("camp_hoe", CampHoeItem::new);
		CAMP_ARMOUR_HELMET = register("camp_armour_helmet", CampArmourItem.Helmet::new);
		CAMP_ARMOUR_CHESTPLATE = register("camp_armour_chestplate", CampArmourItem.Chestplate::new);
		CAMP_ARMOUR_LEGGINGS = register("camp_armour_leggings", CampArmourItem.Leggings::new);
		CAMP_ARMOUR_BOOTS = register("camp_armour_boots", CampArmourItem.Boots::new);
		CAMP_PICKAXE = register("camp_pickaxe", CampPickaxeItem::new);
		CAMP_SHOVEL = register("camp_shovel", CampShovelItem::new);
		CAMP_AXE = register("camp_axe", CampAxeItem::new);
		CAMP_SHEARS = register("camp_shears", CampShearsItem::new);
		SHURIKEN_ITEM = register("shuriken_item", ShurikenItemItem::new);
		MALICIOUS_J_VAMPIRE_SPAWN_EGG = register("malicious_j_vampire_spawn_egg", properties -> new SpawnEggItem(CampModEntities.MALICIOUS_J_VAMPIRE.get(), properties));
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}