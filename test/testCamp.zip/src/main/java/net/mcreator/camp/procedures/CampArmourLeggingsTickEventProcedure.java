package net.mcreator.camp.procedures;

public class CampArmourLeggingsTickEventProcedure {
	public static void execute() {
	}
}