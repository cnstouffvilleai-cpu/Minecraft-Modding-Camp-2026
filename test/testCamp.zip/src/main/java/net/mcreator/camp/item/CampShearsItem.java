package net.mcreator.camp.item;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.ShearsItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.component.DataComponents;

public class CampShearsItem extends ShearsItem {
	public CampShearsItem(Item.Properties properties) {
		super(properties.component(DataComponents.TOOL, ShearsItem.createToolProperties()).repairable(TagKey.create(Registries.ITEM, ResourceLocation.parse("camp:camp_shears_repair_items"))).durability(99999).fireResistant().enchantable(99999));
	}

	@Override
	public float getDestroySpeed(ItemStack stack, BlockState blockstate) {
		return 99999f;
	}
}