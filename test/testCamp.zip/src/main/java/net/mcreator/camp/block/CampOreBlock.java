package net.mcreator.camp.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class CampOreBlock extends Block {
	public CampOreBlock(BlockBehaviour.Properties properties) {
		super(properties.strength(1f, 9.5f).requiresCorrectToolForDrops());
	}
}