package net.mcreator.camp.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class CampPickaxeItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 99999, 99999f, 0, 99999, TagKey.create(Registries.ITEM, ResourceLocation.parse("camp:camp_pickaxe_repair_items")));

	public CampPickaxeItem(Item.Properties properties) {
		super(properties.pickaxe(TOOL_MATERIAL, 99998f, -3.9f).fireResistant());
	}
}