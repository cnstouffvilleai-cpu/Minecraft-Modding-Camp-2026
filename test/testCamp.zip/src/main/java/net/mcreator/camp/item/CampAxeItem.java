package net.mcreator.camp.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class CampAxeItem extends AxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 99999, 99999f, 0, 99999, TagKey.create(Registries.ITEM, ResourceLocation.parse("camp:camp_axe_repair_items")));

	public CampAxeItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 99998f, -3.9f, properties.rarity(Rarity.EPIC).fireResistant());
	}
}