/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.camp.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.camp.block.CampOreBlock;
import net.mcreator.camp.block.CampGrassBlock;
import net.mcreator.camp.CampMod;

import java.util.function.Function;

public class CampModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(CampMod.MODID);
	public static final DeferredBlock<Block> CAMP_GRASS;
	public static final DeferredBlock<Block> CAMP_ORE;
	static {
		CAMP_GRASS = register("camp_grass", CampGrassBlock::new);
		CAMP_ORE = register("camp_ore", CampOreBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}