package net.mcreator.freerobuxclickherenowwww.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.freerobuxclickherenowwww.init.FreeRobuxClickHereNowwwwModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements FreeRobuxClickHereNowwwwModBiomes.FreeRobuxClickHereNowwwwModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> free_robux_click_here_nowwww__dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.free_robux_click_here_nowwww__dimensionTypeReference != null) {
			retval = FreeRobuxClickHereNowwwwModBiomes.adaptSurfaceRule(retval, this.free_robux_click_here_nowwww__dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setfree_robux_click_here_nowwww_DimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.free_robux_click_here_nowwww__dimensionTypeReference = dimensionType;
	}
}