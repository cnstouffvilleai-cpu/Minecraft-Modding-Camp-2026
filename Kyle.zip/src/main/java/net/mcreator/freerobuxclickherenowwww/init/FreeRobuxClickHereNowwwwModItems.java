/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.freerobuxclickherenowwww.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.freerobuxclickherenowwww.item.*;
import net.mcreator.freerobuxclickherenowwww.FreeRobuxClickHereNowwwwMod;

import java.util.function.Function;

public class FreeRobuxClickHereNowwwwModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(FreeRobuxClickHereNowwwwMod.MODID);
	public static final DeferredItem<Item> FREEROBUXCLICKHEHRENOW;
	public static final DeferredItem<Item> NOKIA_3310;
	public static final DeferredItem<Item> GOLDENBARS;
	public static final DeferredItem<Item> OPEXTREMEKATANA;
	public static final DeferredItem<Item> ORANGECHICKEN;
	public static final DeferredItem<Item> SHOAVEL;
	public static final DeferredItem<Item> VANILLAAXE;
	public static final DeferredItem<Item> BULLETPROOFARMOR_HELMET;
	public static final DeferredItem<Item> BULLETPROOFARMOR_CHESTPLATE;
	public static final DeferredItem<Item> BULLETPROOFARMOR_LEGGINGS;
	public static final DeferredItem<Item> BULLETPROOFARMOR_BOOTS;
	public static final DeferredItem<Item> PRO;
	public static final DeferredItem<Item> AMONGUS_SPAWN_EGG;
	public static final DeferredItem<Item> LOGMADEOFCOD;
	public static final DeferredItem<Item> LEAVEZ;
	public static final DeferredItem<Item> MADEOF_4S;
	public static final DeferredItem<Item> DIMENSIONW_4S;
	public static final DeferredItem<Item> GAMEORE;
	static {
		FREEROBUXCLICKHEHRENOW = block(FreeRobuxClickHereNowwwwModBlocks.FREEROBUXCLICKHEHRENOW, new Item.Properties().stacksTo(67).fireResistant());
		NOKIA_3310 = register("nokia_3310", Nokia3310Item::new);
		GOLDENBARS = register("goldenbars", GoldenbarsItem::new);
		OPEXTREMEKATANA = register("opextremekatana", OpextremekatanaItem::new);
		ORANGECHICKEN = register("orangechicken", OrangechickenItem::new);
		SHOAVEL = register("shoavel", ShoavelItem::new);
		VANILLAAXE = register("vanillaaxe", VanillaaxeItem::new);
		BULLETPROOFARMOR_HELMET = register("bulletproofarmor_helmet", BulletproofarmorItem.Helmet::new);
		BULLETPROOFARMOR_CHESTPLATE = register("bulletproofarmor_chestplate", BulletproofarmorItem.Chestplate::new);
		BULLETPROOFARMOR_LEGGINGS = register("bulletproofarmor_leggings", BulletproofarmorItem.Leggings::new);
		BULLETPROOFARMOR_BOOTS = register("bulletproofarmor_boots", BulletproofarmorItem.Boots::new);
		PRO = register("pro", ProItem::new);
		AMONGUS_SPAWN_EGG = register("amongus_spawn_egg", properties -> new SpawnEggItem(properties.spawnEgg(FreeRobuxClickHereNowwwwModEntities.AMONGUS.get())));
		LOGMADEOFCOD = block(FreeRobuxClickHereNowwwwModBlocks.LOGMADEOFCOD);
		LEAVEZ = block(FreeRobuxClickHereNowwwwModBlocks.LEAVEZ);
		MADEOF_4S = block(FreeRobuxClickHereNowwwwModBlocks.MADEOF_4S);
		DIMENSIONW_4S = register("dimensionw_4s", Dimensionw4sItem::new);
		GAMEORE = block(FreeRobuxClickHereNowwwwModBlocks.GAMEORE, new Item.Properties().rarity(Rarity.EPIC));
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, Item.Properties::new);
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), () -> properties);
	}
}