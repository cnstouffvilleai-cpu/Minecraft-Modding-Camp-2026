/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.freerobuxclickherenowwww.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.freerobuxclickherenowwww.client.renderer.AmongusRenderer;

@EventBusSubscriber(Dist.CLIENT)
public class FreeRobuxClickHereNowwwwModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(FreeRobuxClickHereNowwwwModEntities.FORCEFIELD.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(FreeRobuxClickHereNowwwwModEntities.AMONGUS.get(), AmongusRenderer::new);
	}
}