/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.freerobuxclickherenowwww.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.freerobuxclickherenowwww.FreeRobuxClickHereNowwwwMod;

@EventBusSubscriber
public class FreeRobuxClickHereNowwwwModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, FreeRobuxClickHereNowwwwMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(FreeRobuxClickHereNowwwwModBlocks.FREEROBUXCLICKHEHRENOW.get().asItem());
			tabData.accept(FreeRobuxClickHereNowwwwModBlocks.GAMEORE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(FreeRobuxClickHereNowwwwModItems.NOKIA_3310.get());
			tabData.accept(FreeRobuxClickHereNowwwwModItems.ORANGECHICKEN.get());
			tabData.accept(FreeRobuxClickHereNowwwwModItems.SHOAVEL.get());
			tabData.accept(FreeRobuxClickHereNowwwwModItems.VANILLAAXE.get());
			tabData.accept(FreeRobuxClickHereNowwwwModItems.DIMENSIONW_4S.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(FreeRobuxClickHereNowwwwModItems.GOLDENBARS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(FreeRobuxClickHereNowwwwModItems.OPEXTREMEKATANA.get());
			tabData.accept(FreeRobuxClickHereNowwwwModItems.SHOAVEL.get());
			tabData.accept(FreeRobuxClickHereNowwwwModItems.BULLETPROOFARMOR_HELMET.get());
			tabData.accept(FreeRobuxClickHereNowwwwModItems.BULLETPROOFARMOR_CHESTPLATE.get());
			tabData.accept(FreeRobuxClickHereNowwwwModItems.BULLETPROOFARMOR_LEGGINGS.get());
			tabData.accept(FreeRobuxClickHereNowwwwModItems.BULLETPROOFARMOR_BOOTS.get());
			tabData.accept(FreeRobuxClickHereNowwwwModItems.PRO.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FOOD_AND_DRINKS) {
			tabData.accept(FreeRobuxClickHereNowwwwModItems.SHOAVEL.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(FreeRobuxClickHereNowwwwModItems.AMONGUS_SPAWN_EGG.get());
		}
	}
}