/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.freerobuxclickherenowwww.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.freerobuxclickherenowwww.block.*;
import net.mcreator.freerobuxclickherenowwww.FreeRobuxClickHereNowwwwMod;

import java.util.function.Function;

public class FreeRobuxClickHereNowwwwModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(FreeRobuxClickHereNowwwwMod.MODID);
	public static final DeferredBlock<Block> FREEROBUXCLICKHEHRENOW;
	public static final DeferredBlock<Block> LOGMADEOFCOD;
	public static final DeferredBlock<Block> LEAVEZ;
	public static final DeferredBlock<Block> MADEOF_4S;
	public static final DeferredBlock<Block> DIMENSIONW_4S_PORTAL;
	public static final DeferredBlock<Block> GAMEORE;
	static {
		FREEROBUXCLICKHEHRENOW = register("freerobuxclickhehrenow", FREEROBUXCLICKHEHRENOWBlock::new);
		LOGMADEOFCOD = register("logmadeofcod", LogmadeofcodBlock::new);
		LEAVEZ = register("leavez", LeavezBlock::new);
		MADEOF_4S = register("madeof_4s", Madeof4sBlock::new);
		DIMENSIONW_4S_PORTAL = register("dimensionw_4s_portal", Dimensionw4sPortalBlock::new);
		GAMEORE = register("gameore", GameoreBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}