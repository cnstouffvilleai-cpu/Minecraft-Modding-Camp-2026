package net.mcreator.freerobuxclickherenowwww.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class LeavezBlock extends Block {
	public LeavezBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.SCAFFOLDING).strength(0.001f, 0.5f));
	}
}