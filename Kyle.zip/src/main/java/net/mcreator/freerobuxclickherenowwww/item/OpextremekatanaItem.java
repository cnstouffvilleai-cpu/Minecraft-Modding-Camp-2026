package net.mcreator.freerobuxclickherenowwww.item;

import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.*;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import java.util.function.Consumer;

public class OpextremekatanaItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 99999, 99999f, 0, 121, TagKey.create(Registries.ITEM, Identifier.parse("free_robux_click_here_nowwww_:opextremekatana_repair_items")));

	public OpextremekatanaItem(Item.Properties properties) {
		super(properties.sword(TOOL_MATERIAL, 99998f, 96f).fireResistant().setNoCombineRepair());
	}

	@Override
	public ItemStackTemplate getCraftingRemainder(ItemInstance itemInstance) {
		return new ItemStackTemplate(this);
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Item.TooltipContext context, TooltipDisplay tooltipDisplay, Consumer<Component> componentConsumer, TooltipFlag flag) {
		super.appendHoverText(itemstack, context, tooltipDisplay, componentConsumer, flag);
		componentConsumer.accept(Component.translatable("item.free_robux_click_here_nowwww_.opextremekatana.description_0"));
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}