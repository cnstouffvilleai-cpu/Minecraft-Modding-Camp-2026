package net.mcreator.freerobuxclickherenowwww.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class VanillaaxeItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 100, 99999f, 0, 2, TagKey.create(Registries.ITEM, Identifier.parse("free_robux_click_here_nowwww_:vanillaaxe_repair_items")));

	public VanillaaxeItem(Item.Properties properties) {
		super(properties.pickaxe(TOOL_MATERIAL, 3f, -3f).rarity(Rarity.EPIC));
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}