package net.mcreator.freerobuxclickherenowwww.item;

import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.*;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import java.util.function.Consumer;

public class Nokia3310Item extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 10000, 100000f, 0, 2, TagKey.create(Registries.ITEM, Identifier.parse("free_robux_click_here_nowwww_:nokia_3310_repair_items")));

	public Nokia3310Item(Item.Properties properties) {
		super(properties.pickaxe(TOOL_MATERIAL, 9999f, 46.5f).rarity(Rarity.EPIC).fireResistant().setNoCombineRepair());
	}

	@Override
	public ItemStackTemplate getCraftingRemainder(ItemInstance itemInstance) {
		return new ItemStackTemplate(this);
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Item.TooltipContext context, TooltipDisplay tooltipDisplay, Consumer<Component> componentConsumer, TooltipFlag flag) {
		super.appendHoverText(itemstack, context, tooltipDisplay, componentConsumer, flag);
		componentConsumer.accept(Component.translatable("item.free_robux_click_here_nowwww_.nokia_3310.description_0"));
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}