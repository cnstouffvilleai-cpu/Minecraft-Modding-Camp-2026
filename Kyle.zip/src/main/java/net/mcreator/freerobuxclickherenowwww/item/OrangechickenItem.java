package net.mcreator.freerobuxclickherenowwww.item;

import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import java.util.function.Consumer;

public class OrangechickenItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 100, 99999f, 0, 2, TagKey.create(Registries.ITEM, Identifier.parse("free_robux_click_here_nowwww_:orangechicken_repair_items")));

	public OrangechickenItem(Item.Properties properties) {
		super(properties.pickaxe(TOOL_MATERIAL, 99998f, 11.3f).fireResistant());
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Item.TooltipContext context, TooltipDisplay tooltipDisplay, Consumer<Component> componentConsumer, TooltipFlag flag) {
		super.appendHoverText(itemstack, context, tooltipDisplay, componentConsumer, flag);
		componentConsumer.accept(Component.translatable("item.free_robux_click_here_nowwww_.orangechicken.description_0"));
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}