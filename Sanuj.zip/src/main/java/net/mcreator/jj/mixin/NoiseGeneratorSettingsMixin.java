package net.mcreator.jj.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.jj.init.JjModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements JjModBiomes.JjModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> jj_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.jj_dimensionTypeReference != null) {
			retval = JjModBiomes.adaptSurfaceRule(retval, this.jj_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setjjDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.jj_dimensionTypeReference = dimensionType;
	}
}