package net.mcreator.jj.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class HItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 100, 99f, 0, 2, TagKey.create(Registries.ITEM, Identifier.parse("jj:h_repair_items")));

	public HItem(Item.Properties properties) {
		super(properties.pickaxe(TOOL_MATERIAL, 34341f, 66f));
	}
}