package net.mcreator.jj.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class BItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 100, 89f, 0, 2, TagKey.create(Registries.ITEM, Identifier.parse("jj:b_repair_items")));

	public BItem(Item.Properties properties) {
		super(properties.pickaxe(TOOL_MATERIAL, 8879f, 96f));
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}