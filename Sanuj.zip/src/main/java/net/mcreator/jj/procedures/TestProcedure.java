package net.mcreator.jj.procedures;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

public class TestProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double height = 0;
		height = y;
		for (int index349 = 0; index349 < 4; index349++) {
			{
				BlockPos _pos = BlockPos.containing(x, height, z);
				Block.dropResources(world.getBlockState(_pos), world, BlockPos.containing(x, y, z), null);
				world.destroyBlock(_pos, false);
			}
			{
				BlockPos _pos = BlockPos.containing(x + 1, height, z);
				Block.dropResources(world.getBlockState(_pos), world, BlockPos.containing(x, y, z), null);
				world.destroyBlock(_pos, false);
			}
			{
				BlockPos _pos = BlockPos.containing(x - 1, height, z);
				Block.dropResources(world.getBlockState(_pos), world, BlockPos.containing(x, y, z), null);
				world.destroyBlock(_pos, false);
			}
			{
				BlockPos _pos = BlockPos.containing(x - 0, height, z - 1);
				Block.dropResources(world.getBlockState(_pos), world, BlockPos.containing(x, y, z), null);
				world.destroyBlock(_pos, false);
			}
			{
				BlockPos _pos = BlockPos.containing(x - 0, height, z + 1);
				Block.dropResources(world.getBlockState(_pos), world, BlockPos.containing(x, y, z), null);
				world.destroyBlock(_pos, false);
			}
			{
				BlockPos _pos = BlockPos.containing(x + 1, height, z + 1);
				Block.dropResources(world.getBlockState(_pos), world, BlockPos.containing(x, y, z), null);
				world.destroyBlock(_pos, false);
			}
			{
				BlockPos _pos = BlockPos.containing(x + 1, height, z - 1);
				Block.dropResources(world.getBlockState(_pos), world, BlockPos.containing(x, y, z), null);
				world.destroyBlock(_pos, false);
			}
			{
				BlockPos _pos = BlockPos.containing(x - 1, height, z + 1);
				Block.dropResources(world.getBlockState(_pos), world, BlockPos.containing(x, y, z), null);
				world.destroyBlock(_pos, false);
			}
			{
				BlockPos _pos = BlockPos.containing(x - 1, height, z - 1);
				Block.dropResources(world.getBlockState(_pos), world, BlockPos.containing(x, y, z), null);
				world.destroyBlock(_pos, false);
			}
			height = height - 1;
		}
	}
}