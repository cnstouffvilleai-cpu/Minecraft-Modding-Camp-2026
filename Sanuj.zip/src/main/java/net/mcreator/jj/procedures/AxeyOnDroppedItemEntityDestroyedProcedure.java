package net.mcreator.jj.procedures;

public class AxeyOnDroppedItemEntityDestroyedProcedure {
	public static void execute() {
		double yLevel = 0;
	}
}