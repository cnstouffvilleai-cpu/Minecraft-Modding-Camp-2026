/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jj.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.jj.client.renderer.WREDTHTRRenderer;

@EventBusSubscriber(Dist.CLIENT)
public class JjModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(JjModEntities.FIREMIX.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(JjModEntities.WREDTHTR.get(), WREDTHTRRenderer::new);
	}
}