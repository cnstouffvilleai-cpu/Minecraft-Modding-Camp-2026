/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jj.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.jj.item.*;
import net.mcreator.jj.JjMod;

import java.util.function.Function;

public class JjModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(JjMod.MODID);
	public static final DeferredItem<Item> WERGHJ;
	public static final DeferredItem<Item> GGGHBHBKBG;
	public static final DeferredItem<Item> KOJLE;
	public static final DeferredItem<Item> CASWAR;
	public static final DeferredItem<Item> SUPERPICKAXE;
	public static final DeferredItem<Item> AXEY;
	public static final DeferredItem<Item> B;
	public static final DeferredItem<Item> H;
	public static final DeferredItem<Item> YELLOW_HELMET;
	public static final DeferredItem<Item> YELLOW_CHESTPLATE;
	public static final DeferredItem<Item> YELLOW_LEGGINGS;
	public static final DeferredItem<Item> YELLOW_BOOTS;
	public static final DeferredItem<Item> FIREMIX_2;
	public static final DeferredItem<Item> WREDTHTR_SPAWN_EGG;
	public static final DeferredItem<Item> E;
	public static final DeferredItem<Item> WET;
	public static final DeferredItem<Item> BROOOOOOOOOOOOOOOOOOOOO;
	static {
		WERGHJ = block(JjModBlocks.WERGHJ);
		GGGHBHBKBG = block(JjModBlocks.GGGHBHBKBG);
		KOJLE = register("kojle", KojleItem::new);
		CASWAR = register("caswar", CASWARItem::new);
		SUPERPICKAXE = register("superpickaxe", SuperpickaxeItem::new);
		AXEY = register("axey", AxeyItem::new);
		B = register("b", BItem::new);
		H = register("h", HItem::new);
		YELLOW_HELMET = register("yellow_helmet", YellowItem.Helmet::new);
		YELLOW_CHESTPLATE = register("yellow_chestplate", YellowItem.Chestplate::new);
		YELLOW_LEGGINGS = register("yellow_leggings", YellowItem.Leggings::new);
		YELLOW_BOOTS = register("yellow_boots", YellowItem.Boots::new);
		FIREMIX_2 = register("firemix_2", Firemix2Item::new);
		WREDTHTR_SPAWN_EGG = register("wredthtr_spawn_egg", properties -> new SpawnEggItem(properties.spawnEgg(JjModEntities.WREDTHTR.get())));
		E = block(JjModBlocks.E);
		WET = block(JjModBlocks.WET);
		BROOOOOOOOOOOOOOOOOOOOO = register("brooooooooooooooooooooo", BROOOOOOOOOOOOOOOOOOOOOItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, Item.Properties::new);
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), () -> properties);
	}
}