/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jj.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.jj.JjMod;

@EventBusSubscriber
public class JjModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, JjMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> EEEEEEEEEEEEEEEEEEEEEEEEEEEEEESTYEDYD = REGISTRY.register("eeeeeeeeeeeeeeeeeeeeeeeeeeeeeestyedyd",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.jj.eeeeeeeeeeeeeeeeeeeeeeeeeeeeeestyedyd")).icon(() -> new ItemStack(JjModBlocks.GGGHBHBKBG.get())).displayItems((parameters, tabData) -> {
				tabData.accept(JjModBlocks.WERGHJ.get().asItem());
				tabData.accept(JjModItems.KOJLE.get());
				tabData.accept(JjModItems.SUPERPICKAXE.get());
				tabData.accept(JjModItems.AXEY.get());
				tabData.accept(JjModItems.H.get());
				tabData.accept(JjModItems.YELLOW_HELMET.get());
				tabData.accept(JjModItems.YELLOW_CHESTPLATE.get());
				tabData.accept(JjModItems.YELLOW_LEGGINGS.get());
				tabData.accept(JjModItems.YELLOW_BOOTS.get());
				tabData.accept(JjModItems.FIREMIX_2.get());
				tabData.accept(JjModBlocks.E.get().asItem());
				tabData.accept(JjModItems.BROOOOOOOOOOOOOOOOOOOOO.get());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(JjModBlocks.WERGHJ.get().asItem());
			tabData.accept(JjModBlocks.E.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(JjModItems.CASWAR.get());
			tabData.accept(JjModItems.SUPERPICKAXE.get());
			tabData.accept(JjModItems.AXEY.get());
			tabData.accept(JjModItems.B.get());
			tabData.accept(JjModItems.H.get());
			tabData.accept(JjModItems.BROOOOOOOOOOOOOOOOOOOOO.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(JjModItems.YELLOW_HELMET.get());
			tabData.accept(JjModItems.YELLOW_CHESTPLATE.get());
			tabData.accept(JjModItems.YELLOW_LEGGINGS.get());
			tabData.accept(JjModItems.YELLOW_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(JjModItems.WREDTHTR_SPAWN_EGG.get());
		}
	}
}