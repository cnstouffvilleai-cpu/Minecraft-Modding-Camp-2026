/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jj.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.jj.block.WerghjBlock;
import net.mcreator.jj.block.WETBlock;
import net.mcreator.jj.block.GgghbhbkbgBlock;
import net.mcreator.jj.block.EBlock;
import net.mcreator.jj.block.BROOOOOOOOOOOOOOOOOOOOOPortalBlock;
import net.mcreator.jj.JjMod;

import java.util.function.Function;

public class JjModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(JjMod.MODID);
	public static final DeferredBlock<Block> WERGHJ;
	public static final DeferredBlock<Block> GGGHBHBKBG;
	public static final DeferredBlock<Block> E;
	public static final DeferredBlock<Block> WET;
	public static final DeferredBlock<Block> BROOOOOOOOOOOOOOOOOOOOO_PORTAL;
	static {
		WERGHJ = register("werghj", WerghjBlock::new);
		GGGHBHBKBG = register("ggghbhbkbg", GgghbhbkbgBlock::new);
		E = register("e", EBlock::new);
		WET = register("wet", WETBlock::new);
		BROOOOOOOOOOOOOOOOOOOOO_PORTAL = register("brooooooooooooooooooooo_portal", BROOOOOOOOOOOOOOOOOOOOOPortalBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}

	@EventBusSubscriber(Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.BlockTintSources event) {
			WETBlock.blockColorLoad(event);
		}
	}
}