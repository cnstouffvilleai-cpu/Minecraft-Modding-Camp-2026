package net.mcreator.randomminecraftmod.item;

import net.minecraft.world.item.Item;

public class LightningOreItem extends Item {
	public LightningOreItem(Item.Properties properties) {
		super(properties);
	}
}