package net.mcreator.randomminecraftmod.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

public class BloodSwordItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 1000, 100f, 0, 55, TagKey.create(Registries.ITEM, Identifier.parse("random_minecraft_mod:blood_sword_repair_items")));

	public BloodSwordItem(Item.Properties properties) {
		super(properties.sword(TOOL_MATERIAL, 99f, -3f));
	}
}