package net.mcreator.randomminecraftmod.item;

import net.minecraft.world.item.Item;

public class FireOreItem extends Item {
	public FireOreItem(Item.Properties properties) {
		super(properties);
	}
}