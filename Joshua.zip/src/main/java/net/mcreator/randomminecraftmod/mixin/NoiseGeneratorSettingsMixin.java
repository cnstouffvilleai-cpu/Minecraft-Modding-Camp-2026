package net.mcreator.randomminecraftmod.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.randomminecraftmod.init.RandomMinecraftModModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements RandomMinecraftModModBiomes.RandomMinecraftModModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> random_minecraft_mod_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.random_minecraft_mod_dimensionTypeReference != null) {
			retval = RandomMinecraftModModBiomes.adaptSurfaceRule(retval, this.random_minecraft_mod_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setrandom_minecraft_modDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.random_minecraft_mod_dimensionTypeReference = dimensionType;
	}
}