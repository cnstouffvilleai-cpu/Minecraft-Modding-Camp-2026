/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomminecraftmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.randomminecraftmod.item.*;
import net.mcreator.randomminecraftmod.RandomMinecraftModMod;

import java.util.function.Function;

public class RandomMinecraftModModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(RandomMinecraftModMod.MODID);
	public static final DeferredItem<Item> BLOOD_ARMOR_HELMET;
	public static final DeferredItem<Item> BLOOD_ARMOR_CHESTPLATE;
	public static final DeferredItem<Item> BLOOD_ARMOR_LEGGINGS;
	public static final DeferredItem<Item> BLOOD_ARMOR_BOOTS;
	public static final DeferredItem<Item> BLOOD_ORE;
	public static final DeferredItem<Item> BLOOD_INGOT;
	public static final DeferredItem<Item> BLOOD_SWORD;
	public static final DeferredItem<Item> LIGHTNING_SWORD;
	public static final DeferredItem<Item> FIRE_SWORD;
	public static final DeferredItem<Item> FIRE_ORE;
	public static final DeferredItem<Item> LIGHTNING_ORE;
	public static final DeferredItem<Item> SHURIKEN_ITEM;
	public static final DeferredItem<Item> NOOB_SPAWN_EGG;
	public static final DeferredItem<Item> BLOOD_GRASS_BLOCK;
	public static final DeferredItem<Item> BLOOD_LOG;
	public static final DeferredItem<Item> BLOOD_LEAVES;
	public static final DeferredItem<Item> BLOOD_DIMENSION;
	static {
		BLOOD_ARMOR_HELMET = register("blood_armor_helmet", BloodArmorItem.Helmet::new);
		BLOOD_ARMOR_CHESTPLATE = register("blood_armor_chestplate", BloodArmorItem.Chestplate::new);
		BLOOD_ARMOR_LEGGINGS = register("blood_armor_leggings", BloodArmorItem.Leggings::new);
		BLOOD_ARMOR_BOOTS = register("blood_armor_boots", BloodArmorItem.Boots::new);
		BLOOD_ORE = block(RandomMinecraftModModBlocks.BLOOD_ORE);
		BLOOD_INGOT = register("blood_ingot", BloodIngotItem::new);
		BLOOD_SWORD = register("blood_sword", BloodSwordItem::new);
		LIGHTNING_SWORD = register("lightning_sword", LightningSwordItem::new);
		FIRE_SWORD = register("fire_sword", FireSwordItem::new);
		FIRE_ORE = register("fire_ore", FireOreItem::new);
		LIGHTNING_ORE = register("lightning_ore", LightningOreItem::new);
		SHURIKEN_ITEM = register("shuriken_item", ShurikenItemItem::new);
		NOOB_SPAWN_EGG = register("noob_spawn_egg", properties -> new SpawnEggItem(properties.spawnEgg(RandomMinecraftModModEntities.NOOB.get())));
		BLOOD_GRASS_BLOCK = block(RandomMinecraftModModBlocks.BLOOD_GRASS_BLOCK);
		BLOOD_LOG = block(RandomMinecraftModModBlocks.BLOOD_LOG);
		BLOOD_LEAVES = block(RandomMinecraftModModBlocks.BLOOD_LEAVES);
		BLOOD_DIMENSION = register("blood_dimension", BloodDimensionItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, Item.Properties::new);
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), () -> properties);
	}
}