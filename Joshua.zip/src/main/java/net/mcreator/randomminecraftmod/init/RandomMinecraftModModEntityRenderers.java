/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomminecraftmod.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.randomminecraftmod.client.renderer.NoobRenderer;

@EventBusSubscriber(Dist.CLIENT)
public class RandomMinecraftModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(RandomMinecraftModModEntities.SHURIKEN.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(RandomMinecraftModModEntities.NOOB.get(), NoobRenderer::new);
	}
}