/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomminecraftmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.randomminecraftmod.RandomMinecraftModMod;

@EventBusSubscriber
public class RandomMinecraftModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RandomMinecraftModMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> BLOOD = REGISTRY.register("blood",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.random_minecraft_mod.blood")).icon(() -> new ItemStack(RandomMinecraftModModBlocks.BLOOD_ORE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(RandomMinecraftModModItems.BLOOD_ARMOR_HELMET.get());
				tabData.accept(RandomMinecraftModModItems.BLOOD_ARMOR_CHESTPLATE.get());
				tabData.accept(RandomMinecraftModModItems.BLOOD_ARMOR_LEGGINGS.get());
				tabData.accept(RandomMinecraftModModItems.BLOOD_ARMOR_BOOTS.get());
				tabData.accept(RandomMinecraftModModBlocks.BLOOD_ORE.get().asItem());
				tabData.accept(RandomMinecraftModModItems.BLOOD_INGOT.get());
				tabData.accept(RandomMinecraftModModItems.BLOOD_SWORD.get());
				tabData.accept(RandomMinecraftModModItems.SHURIKEN_ITEM.get());
				tabData.accept(RandomMinecraftModModBlocks.BLOOD_GRASS_BLOCK.get().asItem());
				tabData.accept(RandomMinecraftModModBlocks.BLOOD_LOG.get().asItem());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(RandomMinecraftModModItems.BLOOD_ARMOR_HELMET.get());
			tabData.accept(RandomMinecraftModModItems.BLOOD_ARMOR_CHESTPLATE.get());
			tabData.accept(RandomMinecraftModModItems.BLOOD_ARMOR_LEGGINGS.get());
			tabData.accept(RandomMinecraftModModItems.BLOOD_ARMOR_BOOTS.get());
			tabData.accept(RandomMinecraftModModItems.LIGHTNING_SWORD.get());
			tabData.accept(RandomMinecraftModModItems.SHURIKEN_ITEM.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(RandomMinecraftModModBlocks.BLOOD_ORE.get().asItem());
			tabData.accept(RandomMinecraftModModBlocks.BLOOD_GRASS_BLOCK.get().asItem());
			tabData.accept(RandomMinecraftModModBlocks.BLOOD_LOG.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(RandomMinecraftModModItems.BLOOD_INGOT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(RandomMinecraftModModItems.FIRE_SWORD.get());
			tabData.accept(RandomMinecraftModModItems.BLOOD_DIMENSION.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(RandomMinecraftModModItems.NOOB_SPAWN_EGG.get());
		}
	}
}