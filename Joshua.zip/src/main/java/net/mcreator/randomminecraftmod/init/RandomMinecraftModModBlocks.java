/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.randomminecraftmod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.randomminecraftmod.block.BloodOreBlock;
import net.mcreator.randomminecraftmod.block.BloodLogBlock;
import net.mcreator.randomminecraftmod.block.BloodLeavesBlock;
import net.mcreator.randomminecraftmod.block.BloodGrassBlockBlock;
import net.mcreator.randomminecraftmod.block.BloodDimensionPortalBlock;
import net.mcreator.randomminecraftmod.RandomMinecraftModMod;

import java.util.function.Function;

public class RandomMinecraftModModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(RandomMinecraftModMod.MODID);
	public static final DeferredBlock<Block> BLOOD_ORE;
	public static final DeferredBlock<Block> BLOOD_GRASS_BLOCK;
	public static final DeferredBlock<Block> BLOOD_LOG;
	public static final DeferredBlock<Block> BLOOD_LEAVES;
	public static final DeferredBlock<Block> BLOOD_DIMENSION_PORTAL;
	static {
		BLOOD_ORE = register("blood_ore", BloodOreBlock::new);
		BLOOD_GRASS_BLOCK = register("blood_grass_block", BloodGrassBlockBlock::new);
		BLOOD_LOG = register("blood_log", BloodLogBlock::new);
		BLOOD_LEAVES = register("blood_leaves", BloodLeavesBlock::new);
		BLOOD_DIMENSION_PORTAL = register("blood_dimension_portal", BloodDimensionPortalBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}