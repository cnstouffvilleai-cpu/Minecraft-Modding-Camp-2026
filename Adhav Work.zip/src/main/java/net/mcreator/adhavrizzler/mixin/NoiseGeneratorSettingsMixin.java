package net.mcreator.adhavrizzler.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.adhavrizzler.init.AdhavRizzlerModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements AdhavRizzlerModBiomes.AdhavRizzlerModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> adhav_rizzler_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.adhav_rizzler_dimensionTypeReference != null) {
			retval = AdhavRizzlerModBiomes.adaptSurfaceRule(retval, this.adhav_rizzler_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setadhav_rizzlerDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.adhav_rizzler_dimensionTypeReference = dimensionType;
	}
}