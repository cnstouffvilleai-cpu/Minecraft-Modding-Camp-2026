package net.mcreator.adhavrizzler.block;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class BluestoneBlock extends Block {
	public BluestoneBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.SAND).strength(4f, 10f).requiresCorrectToolForDrops());
	}
}