package net.mcreator.adhavrizzler.block;

import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.UntintedParticleLeavesBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ColorParticleOption;

public class Leaves61Block extends UntintedParticleLeavesBlock {
	public Leaves61Block(BlockBehaviour.Properties properties) {
		super(0.001f, ColorParticleOption.create(ParticleTypes.TINTED_LEAVES, -6771908), properties.sound(SoundType.GRAVEL).strength(2.5f, 34.5f).noOcclusion().pushReaction(PushReaction.DESTROY).postProcess((bs, br, bp) -> bp)
				.emissiveRendering((bs, br, bp) -> true).isRedstoneConductor((bs, br, bp) -> false).ignitedByLava().isSuffocating((bs, br, bp) -> false).isViewBlocking((bs, br, bp) -> false));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state) {
		return true;
	}

	@Override
	public int getLightDampening(BlockState state) {
		return 0;
	}
}