package net.mcreator.adhavrizzler.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

import net.mcreator.adhavrizzler.procedures.ELECTRICAXELivingEntityIsHitWithToolProcedure;

public class ELECTRICAXEItem extends AxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 20000, 99999f, 0, 99999, TagKey.create(Registries.ITEM, Identifier.parse("adhav_rizzler:electricaxe_repair_items")));

	public ELECTRICAXEItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 99998f, 96f, properties.rarity(Rarity.EPIC).fireResistant());
	}

	@Override
	public void hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		super.hurtEnemy(itemstack, entity, sourceentity);
		ELECTRICAXELivingEntityIsHitWithToolProcedure.execute(entity);
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}