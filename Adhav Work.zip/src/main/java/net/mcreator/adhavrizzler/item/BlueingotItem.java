package net.mcreator.adhavrizzler.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStackTemplate;
import net.minecraft.world.item.ItemInstance;
import net.minecraft.world.item.Item;

public class BlueingotItem extends Item {
	public BlueingotItem(Item.Properties properties) {
		super(properties.rarity(Rarity.RARE).fireResistant());
	}

	@Override
	public ItemStackTemplate getCraftingRemainder(ItemInstance itemInstance) {
		return new ItemStackTemplate(this);
	}
}