package net.mcreator.adhavrizzler.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;

import net.mcreator.adhavrizzler.procedures.ELECTIRCPICKAXELivingEntityIsHitWithToolProcedure;

public class ELECTIRCPICKAXEItem extends Item {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 2000, 99999f, 0, 99999, TagKey.create(Registries.ITEM, Identifier.parse("adhav_rizzler:electircpickaxe_repair_items")));

	public ELECTIRCPICKAXEItem(Item.Properties properties) {
		super(properties.pickaxe(TOOL_MATERIAL, 99998f, 96f).rarity(Rarity.EPIC).fireResistant());
	}

	@Override
	public void hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		super.hurtEnemy(itemstack, entity, sourceentity);
		ELECTIRCPICKAXELivingEntityIsHitWithToolProcedure.execute(entity);
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}