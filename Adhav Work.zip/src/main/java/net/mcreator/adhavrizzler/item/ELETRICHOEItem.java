package net.mcreator.adhavrizzler.item;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.Identifier;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.BlockPos;

import net.mcreator.adhavrizzler.procedures.ELETRICHOEBlockDestroyedWithToolProcedure;

public class ELETRICHOEItem extends HoeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 20000, 99999f, 0, 99999, TagKey.create(Registries.ITEM, Identifier.parse("adhav_rizzler:eletrichoe_repair_items")));

	public ELETRICHOEItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 99998f, 96f, properties.rarity(Rarity.EPIC).fireResistant());
	}

	@Override
	public boolean mineBlock(ItemStack itemstack, Level world, BlockState blockstate, BlockPos pos, LivingEntity entity) {
		boolean retval = super.mineBlock(itemstack, world, blockstate, pos, entity);
		ELETRICHOEBlockDestroyedWithToolProcedure.execute(entity);
		return retval;
	}

	@Override
	public boolean isFoil(ItemStack itemstack) {
		return true;
	}
}