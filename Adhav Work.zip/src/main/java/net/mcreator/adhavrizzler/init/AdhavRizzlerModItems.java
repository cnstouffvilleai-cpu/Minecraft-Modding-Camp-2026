/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.adhavrizzler.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.adhavrizzler.item.*;
import net.mcreator.adhavrizzler.AdhavRizzlerMod;

import java.util.function.Function;

public class AdhavRizzlerModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(AdhavRizzlerMod.MODID);
	public static final DeferredItem<Item> GRASS_61;
	public static final DeferredItem<Item> BLUESTONE;
	public static final DeferredItem<Item> BLUEINGOT;
	public static final DeferredItem<Item> ELECTRICSWORD;
	public static final DeferredItem<Item> ELECTIRCPICKAXE;
	public static final DeferredItem<Item> ELECTRICAXE;
	public static final DeferredItem<Item> ELECTRICSPADE;
	public static final DeferredItem<Item> ELETRICHOE;
	public static final DeferredItem<Item> BLUESTONEARMOUR_HELMET;
	public static final DeferredItem<Item> BLUESTONEARMOUR_CHESTPLATE;
	public static final DeferredItem<Item> BLUESTONEARMOUR_LEGGINGS;
	public static final DeferredItem<Item> BLUESTONEARMOUR_BOOTS;
	public static final DeferredItem<Item> ELECTRICUUU;
	public static final DeferredItem<Item> CHICKENNUGGET_SPAWN_EGG;
	public static final DeferredItem<Item> LOG_61;
	public static final DeferredItem<Item> LEAVES_61;
	public static final DeferredItem<Item> BLUEOY;
	static {
		GRASS_61 = block(AdhavRizzlerModBlocks.GRASS_61, new Item.Properties().fireResistant());
		BLUESTONE = block(AdhavRizzlerModBlocks.BLUESTONE, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
		BLUEINGOT = register("blueingot", BlueingotItem::new);
		ELECTRICSWORD = register("electricsword", ElectricswordItem::new);
		ELECTIRCPICKAXE = register("electircpickaxe", ELECTIRCPICKAXEItem::new);
		ELECTRICAXE = register("electricaxe", ELECTRICAXEItem::new);
		ELECTRICSPADE = register("electricspade", ELECTRICSPADEItem::new);
		ELETRICHOE = register("eletrichoe", ELETRICHOEItem::new);
		BLUESTONEARMOUR_HELMET = register("bluestonearmour_helmet", BLUESTONEARMOURItem.Helmet::new);
		BLUESTONEARMOUR_CHESTPLATE = register("bluestonearmour_chestplate", BLUESTONEARMOURItem.Chestplate::new);
		BLUESTONEARMOUR_LEGGINGS = register("bluestonearmour_leggings", BLUESTONEARMOURItem.Leggings::new);
		BLUESTONEARMOUR_BOOTS = register("bluestonearmour_boots", BLUESTONEARMOURItem.Boots::new);
		ELECTRICUUU = register("electricuuu", ElectricuuuItem::new);
		CHICKENNUGGET_SPAWN_EGG = register("chickennugget_spawn_egg", properties -> new SpawnEggItem(properties.spawnEgg(AdhavRizzlerModEntities.CHICKENNUGGET.get())));
		LOG_61 = block(AdhavRizzlerModBlocks.LOG_61, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
		LEAVES_61 = block(AdhavRizzlerModBlocks.LEAVES_61, new Item.Properties().fireResistant());
		BLUEOY = register("blueoy", BlueoyItem::new);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, Item.Properties::new);
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), () -> properties);
	}
}