/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.adhavrizzler.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.adhavrizzler.block.Log61Block;
import net.mcreator.adhavrizzler.block.Leaves61Block;
import net.mcreator.adhavrizzler.block.Grass61Block;
import net.mcreator.adhavrizzler.block.BluestoneBlock;
import net.mcreator.adhavrizzler.block.BlueoyPortalBlock;
import net.mcreator.adhavrizzler.AdhavRizzlerMod;

import java.util.function.Function;

public class AdhavRizzlerModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(AdhavRizzlerMod.MODID);
	public static final DeferredBlock<Block> GRASS_61;
	public static final DeferredBlock<Block> BLUESTONE;
	public static final DeferredBlock<Block> LOG_61;
	public static final DeferredBlock<Block> LEAVES_61;
	public static final DeferredBlock<Block> BLUEOY_PORTAL;
	static {
		GRASS_61 = register("grass_61", Grass61Block::new);
		BLUESTONE = register("bluestone", BluestoneBlock::new);
		LOG_61 = register("log_61", Log61Block::new);
		LEAVES_61 = register("leaves_61", Leaves61Block::new);
		BLUEOY_PORTAL = register("blueoy_portal", BlueoyPortalBlock::new);
	}

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier);
	}
}