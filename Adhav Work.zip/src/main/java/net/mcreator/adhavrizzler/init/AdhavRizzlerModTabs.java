/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.adhavrizzler.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.adhavrizzler.AdhavRizzlerMod;

@EventBusSubscriber
public class AdhavRizzlerModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AdhavRizzlerMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> BELLO = REGISTRY.register("bello",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.adhav_rizzler.bello")).icon(() -> new ItemStack(AdhavRizzlerModBlocks.BLUESTONE.get())).displayItems((parameters, tabData) -> {
				tabData.accept(AdhavRizzlerModItems.BLUEINGOT.get());
				tabData.accept(AdhavRizzlerModItems.ELECTRICSWORD.get());
				tabData.accept(AdhavRizzlerModItems.ELECTIRCPICKAXE.get());
				tabData.accept(AdhavRizzlerModItems.ELECTRICAXE.get());
				tabData.accept(AdhavRizzlerModItems.ELECTRICSPADE.get());
				tabData.accept(AdhavRizzlerModItems.BLUESTONEARMOUR_HELMET.get());
				tabData.accept(AdhavRizzlerModItems.BLUESTONEARMOUR_CHESTPLATE.get());
				tabData.accept(AdhavRizzlerModItems.BLUESTONEARMOUR_LEGGINGS.get());
				tabData.accept(AdhavRizzlerModItems.BLUESTONEARMOUR_BOOTS.get());
				tabData.accept(AdhavRizzlerModItems.ELECTRICUUU.get());
				tabData.accept(AdhavRizzlerModBlocks.LOG_61.get().asItem());
				tabData.accept(AdhavRizzlerModBlocks.LEAVES_61.get().asItem());
				tabData.accept(AdhavRizzlerModItems.BLUEOY.get());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(AdhavRizzlerModBlocks.BLUESTONE.get().asItem());
			tabData.accept(AdhavRizzlerModBlocks.LOG_61.get().asItem());
			tabData.accept(AdhavRizzlerModBlocks.LEAVES_61.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(AdhavRizzlerModItems.ELECTRICSWORD.get());
			tabData.accept(AdhavRizzlerModItems.BLUESTONEARMOUR_HELMET.get());
			tabData.accept(AdhavRizzlerModItems.BLUESTONEARMOUR_CHESTPLATE.get());
			tabData.accept(AdhavRizzlerModItems.BLUESTONEARMOUR_LEGGINGS.get());
			tabData.accept(AdhavRizzlerModItems.BLUESTONEARMOUR_BOOTS.get());
			tabData.accept(AdhavRizzlerModItems.ELECTRICUUU.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(AdhavRizzlerModItems.ELECTIRCPICKAXE.get());
			tabData.accept(AdhavRizzlerModItems.ELECTRICAXE.get());
			tabData.accept(AdhavRizzlerModItems.ELECTRICSPADE.get());
			tabData.accept(AdhavRizzlerModItems.ELETRICHOE.get());
			tabData.accept(AdhavRizzlerModItems.BLUEOY.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(AdhavRizzlerModItems.CHICKENNUGGET_SPAWN_EGG.get());
		}
	}
}