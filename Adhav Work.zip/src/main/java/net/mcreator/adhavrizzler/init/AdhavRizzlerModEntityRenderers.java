/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.adhavrizzler.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.adhavrizzler.client.renderer.ChickennuggetRenderer;

@EventBusSubscriber(Dist.CLIENT)
public class AdhavRizzlerModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(AdhavRizzlerModEntities.ELECTRICBOMB.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(AdhavRizzlerModEntities.CHICKENNUGGET.get(), ChickennuggetRenderer::new);
	}
}